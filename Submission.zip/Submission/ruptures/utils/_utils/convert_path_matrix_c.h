void convert_path_matrix_c(int *path_matrix, int n_bkps, int n_samples, int n_bkps_max, int jump, int *bkps_list);
